package model.type;

public interface IType {
    boolean equals(Object another);
}
