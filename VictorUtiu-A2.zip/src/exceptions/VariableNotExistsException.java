package exceptions;

public class VariableNotExistsException extends Exception {
    public VariableNotExistsException(String message) {
        super(message);
    }
}
