package exceptions;

public class StackIsEmptyException extends Exception {
    public StackIsEmptyException(String message) {
        super(message);
    }
}