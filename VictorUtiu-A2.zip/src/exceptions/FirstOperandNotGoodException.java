package exceptions;

public class FirstOperandNotGoodException extends Exception {
    public FirstOperandNotGoodException(String message) {
        super(message);
    }
}
