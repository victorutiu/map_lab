package exceptions;

public class VariableAlreadyExistsException extends Exception{
    public VariableAlreadyExistsException(String message){
        super(message);
    }
}
