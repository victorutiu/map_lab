package exceptions;

public class DictionaryException extends Exception {
    public DictionaryException(String message) {
        super(message);
    }

}
