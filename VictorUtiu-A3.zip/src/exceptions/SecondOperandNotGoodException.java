package exceptions;

public class SecondOperandNotGoodException extends Exception {
    public SecondOperandNotGoodException(String message) {
        super(message);
    }
}
